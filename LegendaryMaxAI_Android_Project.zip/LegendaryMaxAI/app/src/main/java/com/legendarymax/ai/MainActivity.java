package com.legendarymax.ai;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    TextView status; TextToSpeech tts; final int REQ=42;
    final ActivityResultReceiver receiver = new ActivityResultReceiver();
    @Override public void onCreate(Bundle b) { super.onCreate(b); tts=new TextToSpeech(this,this); build(); requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO,Manifest.permission.READ_CONTACTS},REQ); }
    void build(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(32,60,32,24); box.setGravity(Gravity.CENTER_HORIZONTAL); box.setBackgroundColor(0xff050712);
        TextView title=t("LEGENDARY MAX AI",30,0xff22c8ff); title.setGravity(17); box.addView(title,new LinearLayout.LayoutParams(-1,80));
        TextView sub=t("Aap boliye, Max kaam karega.",18,Color.WHITE); sub.setGravity(17); box.addView(sub,new LinearLayout.LayoutParams(-1,60));
        ImageView icon=new ImageView(this); icon.setImageResource(com.legendarymax.ai.R.drawable.max_icon); icon.setScaleType(ImageView.ScaleType.CENTER_CROP); box.addView(icon,new LinearLayout.LayoutParams(-1,300));
        status=t("Ready — Tap the mic and speak",16,0xffb9c7ff); status.setGravity(17); box.addView(status,new LinearLayout.LayoutParams(-1,80));
        Button mic=new Button(this); mic.setText("🎙  SPEAK TO MAX"); mic.setTextSize(18); mic.setOnClickListener(v->listen()); box.addView(mic,new LinearLayout.LayoutParams(-1,120));
        Button access=new Button(this); access.setText("⚙  ENABLE FULL CONTROL"); access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); box.addView(access,new LinearLayout.LayoutParams(-1,100));
        TextView examples=t("Try: WhatsApp kholo • YouTube kholo • Camera kholo • Wi-Fi settings • volume 50 • back • home • notifications",14,0xffdddddd); examples.setPadding(8,20,8,0); box.addView(examples,new LinearLayout.LayoutParams(-1,-2));
        setContentView(box);
    }
    TextView t(String s,float z,int c){ TextView x=new TextView(this); x.setText(s); x.setTextSize(z); x.setTextColor(c); return x; }
    void listen(){ Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN"); i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Max ko command dijiye..."); startActivityForResult(i,100); }
    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(r==100&&c==RESULT_OK&&d!=null){ArrayList<String>a=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS); if(a!=null&&!a.isEmpty()){status.setText("You: "+a.get(0)); execute(a.get(0));}}}
    void execute(String raw){ String s=raw.toLowerCase(Locale.ROOT).trim();
        if(s.contains("back")||s.contains("पीछे")){ if(MaxAccessibilityService.instance!=null){MaxAccessibilityService.instance.doGlobal("back"); speak("Back kar diya.");} else needAccess(); return; }
        if(s.equals("home")||s.contains("होम")){ if(MaxAccessibilityService.instance!=null){MaxAccessibilityService.instance.doGlobal("home"); speak("Home par aa gaye.");} else needAccess(); return; }
        if(s.contains("notification")){ if(MaxAccessibilityService.instance!=null){MaxAccessibilityService.instance.doGlobal("notifications"); speak("Notifications khol raha hoon.");} else needAccess(); return; }
        if(s.contains("whatsapp")){open("com.whatsapp","WhatsApp khol raha hoon.");return;}
        if(s.contains("youtube")){open("com.google.android.youtube","YouTube khol raha hoon.");return;}
        if(s.contains("camera")){openIntent(new Intent("android.media.action.IMAGE_CAPTURE"),"Camera khol raha hoon.");return;}
        if(s.contains("wifi")){openIntent(new Intent(Settings.ACTION_WIFI_SETTINGS),"Wi-Fi settings khol raha hoon.");return;}
        if(s.contains("bluetooth")){openIntent(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS),"Bluetooth settings khol raha hoon.");return;}
        if(s.contains("setting")){openIntent(new Intent(Settings.ACTION_SETTINGS),"Settings khol raha hoon.");return;}
        if(s.contains("volume")){AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE); am.adjustVolume(AudioManager.ADJUST_RAISE,AudioManager.FLAG_SHOW_UI); speak("Volume control khol diya.");return;}
        if(s.contains("call")||s.contains("फोन")){speak("Call ke liye contact ka naam batayein. Main dialer khol sakta hoon."); openIntent(new Intent(Intent.ACTION_DIAL),"Dialer khol raha hoon.");return;}
        speak("Main samjha: "+raw+". Is command ka action abhi available nahi hai.");
    }
    void open(String pkg,String msg){Intent i=getPackageManager().getLaunchIntentForPackage(pkg); if(i!=null)openIntent(i,msg); else speak("Yeh app installed nahi hai.");}
    void openIntent(Intent i,String msg){try{startActivity(i);speak(msg);}catch(Exception e){speak("Yeh action available nahi hai.");}}
    void needAccess(){speak("Full phone control ke liye Accessibility permission enable karein."); startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}
    void speak(String s){status.setText(s); if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"max");}
    @Override public void onInit(int code){if(tts!=null)tts.setLanguage(new Locale("hi","IN"));}
    @Override protected void onDestroy(){if(tts!=null)tts.shutdown();super.onDestroy();}
    class ActivityResultReceiver{}
}
