# Legendary Max AI — Voice Control Android App

Package: `com.legendarymax.ai`

This is a buildable Android Studio starter app for a voice-controlled assistant.

## Included
- Hindi speech recognition using Android SpeechRecognizer
- Hindi text-to-speech response
- Open WhatsApp, YouTube and Camera by voice
- Open Wi-Fi, Bluetooth and system Settings
- Dialer launch for call commands
- Accessibility Service for explicit Back, Home and Notifications commands
- Legendary Max app icon
- Dark futuristic UI

## Build
Open the project folder in Android Studio, sync Gradle, then Run or Build APK.

## Important Android limitation
A normal app cannot silently control everything on a phone. Advanced actions require user-enabled Accessibility permission and some actions remain restricted by Android. This project only performs explicit commands.
